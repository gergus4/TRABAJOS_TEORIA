﻿//primera linea
for (int i = 1; i <= 9; i++)
{
    Console.Write("x");
}
Console.Write(" ");
for (int i = 1; i <= 9; i++)
{
    Console.Write("x");
}
Console.WriteLine("");
//segunda línea
for (int i = 1; i <= 4; i++)
{
    Console.WriteLine("x            x");
}
for (int i = 1; i <= 9; i++)
{
    Console.Write("x");
}
Console.Write("    x");
Console.WriteLine("");
//última línea
for (int i = 1; i <= 4; i++)
{
    Console.WriteLine("x            x");
}
for (int i = 1; i <= 9; i++)
{
    Console.Write("x");
}
Console.Write(" ");

for (int i = 1; i <= 9; i++)
{
    Console.Write("x");
}
Console.WriteLine("");