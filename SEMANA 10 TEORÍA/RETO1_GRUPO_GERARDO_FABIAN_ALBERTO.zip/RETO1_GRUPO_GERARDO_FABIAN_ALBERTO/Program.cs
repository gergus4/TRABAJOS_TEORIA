﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int valor;
        string nombre;

        double resultado = alCuadrado(10);
        Console.WriteLine("Ingresa tu nomnre");
        nombre = Console.ReadLine();

        Console.Write("Hola " + nombre);
        Console.WriteLine(" ingresa el  número del que quieras obtener su cuadrado");
        valor = Int32.Parse(Console.ReadLine());

        Console.WriteLine("El cuadrado del número ingresado es " + resultado);
    }

    public static int alCuadrado(int valor)
    {
        int resultado;
        resultado = valor*valor;
        return resultado;
    }

}